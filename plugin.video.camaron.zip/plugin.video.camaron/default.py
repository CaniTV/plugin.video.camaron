# -*- coding: utf-8 -*-
#------------------------------------------------------------
# License: GPL (http://www.gnu.org/licenses/gpl-3.0.html)
# Based on code from youtube addon
#------------------------------------------------------------

import os
import sys
import plugintools
import xbmc,xbmcaddon
from addon.common.addon import Addon

addonID = 'plugin.video.camaron'
addon = Addon(addonID, sys.argv)
local = xbmcaddon.Addon(id=addonID)
icon = local.getAddonInfo('icon')

YOUTUBE_CHANNEL_ID1 = "UC8zicr_LQfQQvrpjzSRuTAw"
YOUTUBE_CHANNEL_ID2 = "PLkM_hHE1ktwYEO8TphiBwey82mrWcbH5c"
YOUTUBE_CHANNEL_ID3 = "PLIw1WGA25wxHbsCKwDkE535x4EtlRHnhN"









# Entry point
def run():
    plugintools.log("camaron.run")
    
    # Get params
    params = plugintools.get_params()
    
    if params.get("action") is None:
        main_list(params)
    else:
        pass
    
    plugintools.close_item_list()

# Main menu
def main_list(params):
    plugintools.log("camaron.main_list "+repr(params))

    plugintools.add_item( 
        #action="", 
        title="DISCOGRAFÍA COMPLETA",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID1+"/",
        thumbnail="https://i.pinimg.com/564x/2c/3f/68/2c3f683cf0f94370ad368a5a78aa910f.jpg",
        folder=True )
 
    plugintools.add_item( 
        #action="", 
        title="CAMARON PELICULA",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID2+"/",
        thumbnail="https://images-na.ssl-images-amazon.com/images/I/91TJ%2BMUDWiL._SY445_.jpg",
        folder=True )
    
    plugintools.add_item( 
        #action="", 
        title="CAMARON REVOLUTION",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID3+"/",
        thumbnail="https://pics.filmaffinity.com/Camar_n_De_la_isla_al_mito_Miniserie_de_TV-386715681-large.jpg",
        folder=True )

        
run()
